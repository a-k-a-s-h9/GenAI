# GenAI Knowledge Assistant - RAG Pipeline Documentation

## 📚 Complete RAG Flow Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        USER INTERACTION                              │
│                    Web Browser (Flask UI)                            │
│              Responsive HTML Form + JavaScript                       │
└────────────────────────────┬──────────────────────────────────────────┘
                             │
                             │ POST /ask (question)
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     FLASK BACKEND (app.py)                          │
│                    - Request Handler Route                          │
│                    - Error Management                               │
│                    - Response Formatting                            │
└────────────┬────────────────────────────────────────────┬───────────┘
             │                                            │
             ▼                                            ▼
    ┌─────────────────────┐              ┌──────────────────────────┐
    │ STEP 1: EMBEDDING   │              │ STEP 2: RETRIEVAL       │
    ├─────────────────────┤              ├──────────────────────────┤
    │ Model: Sentence-    │              │ Database: ChromaDB       │
    │ Transformer         │              │ Metric: Cosine Similarity│
    │ (all-MiniLM-L6-v2)  │              │ Top-K: 3 Documents      │
    │                     │              │                          │
    │ Convert user query  │──────────────│ Search & Rank by:        │
    │ to 384-dim vector   │              │ - Semantic Similarity    │
    │                     │              │ - Distance Score         │
    └─────────────────────┘              │ - Metadata (Topic)       │
                                         └──────────────────────────┘
                                                   │
                                                   ▼
                        ┌──────────────────────────────────────────────┐
                        │ STEP 3: CONTEXT ASSEMBLY                    │
                        ├──────────────────────────────────────────────┤
                        │ Retrieved Documents:                         │
                        │  • Document 1: {text, topic, distance}      │
                        │  • Document 2: {text, topic, distance}      │
                        │  • Document 3: {text, topic, distance}      │
                        │                                              │
                        │ Similarity Scores:                           │
                        │  • 1 - distance = similarity                │
                        │  • Higher = more relevant                   │
                        │                                              │
                        │ Prepare prompt with:                         │
                        │  • Persona: GenAI training assistant        │
                        │  • Context: Retrieved documents             │
                        │  • Task: Clear, beginner-friendly answer    │
                        │  • Constraints: Simple language, 2-3 sen.   │
                        └──────────────────────────────────────────────┘
                                           │
                                           ▼
                        ┌──────────────────────────────────────────────┐
                        │ STEP 4: LLM API CALL                         │
                        ├──────────────────────────────────────────────┤
                        │ Provider: Anthropic                          │
                        │ Model: Claude 3.5 Sonnet                     │
                        │ Method: REST API (HTTPS POST)                │
                        │ Endpoint: /v1/messages                       │
                        │                                              │
                        │ Headers:                                     │
                        │  • x-api-key: {ANTHROPIC_API_KEY}           │
                        │  • anthropic-version: 2023-06-01             │
                        │  • content-type: application/json            │
                        │                                              │
                        │ Payload:                                     │
                        │  • model: claude-3-5-sonnet-20241022        │
                        │  • max_tokens: 500                           │
                        │  • messages: [{role, content}]               │
                        │                                              │
                        │ Error Handling:                              │
                        │  • 401: Unauthorized (invalid key)           │
                        │  • 404: Not Found (invalid endpoint)         │
                        │  • 405: Method Not Allowed                   │
                        │  • Timeout: Connection issues                │
                        └──────────────────────────────────────────────┘
                                           │
                                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    STEP 5: RESPONSE GENERATION                      │
│                 Claude LLM Processes Prompt and:                    │
│  1. Analyzes retrieved context documents                            │
│  2. Relates context to user question                                │
│  3. Generates clear, beginner-friendly explanation                 │
│  4. Stays within token limit (500 tokens max)                       │
│  5. Uses simple language, avoids jargon                             │
│                                                                     │
│  Output: "Embeddings are numerical vectors that capture..."         │
└─────────────────────┬──────────────────────────────────────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │ STEP 6: RESPONSE ASSEMBLY  │
         ├────────────────────────────┤
         │ Compile JSON response:     │
         │ {                          │
         │   question: "...",         │
         │   retrieved_context: [     │
         │     {text, topic, dist}    │
         │   ],                       │
         │   answer: "...",           │
         │   num_docs_retrieved: 3    │
         │ }                          │
         └────────────────────────────┘
                      │
                      │ JSON Response
                      ▼
         ┌────────────────────────────┐
         │ STEP 7: DISPLAY IN UI      │
         ├────────────────────────────┤
         │ • Show user question       │
         │ • Display context chunks   │
         │ • Show similarity scores   │
         │ • Render LLM answer        │
         │ • Display doc count stats  │
         └────────────────────────────┘
```

## 🔄 Data Flow Examples

### Example 1: Embeddings Question

```
Input: "What is the role of embeddings in GenAI?"
       ↓
Embedding: [0.123, -0.456, 0.789, ..., 0.234] (384 dimensions)
       ↓
ChromaDB Search Result:
  Doc 1: "Embeddings are numerical vector representations..."
         Similarity: 0.8923 (Distance: 0.1077)
  Doc 2: "Semantic search compares meaning rather than keywords..."
         Similarity: 0.7845 (Distance: 0.2155)
  Doc 3: "Vector databases store embeddings and retrieve..."
         Similarity: 0.7234 (Distance: 0.2766)
       ↓
LLM Prompt:
  "You are a helpful GenAI training assistant...
   Context: [3 documents above]
   Question: What is the role of embeddings in GenAI?
   Provide a clear, beginner-friendly answer..."
       ↓
Claude Response:
  "Embeddings are numerical representations that capture the meaning 
   of text, allowing AI systems to understand semantic relationships. 
   They enable vector databases like ChromaDB to find similar content 
   quickly, which is essential for RAG systems to retrieve relevant 
   information before generating responses."
```

## 📊 Evaluation Against Requirements

| Requirement | Status | Implementation |
|-------------|--------|-----------------|
| Flask UI | ✅ | `templates/index.html` with form & display |
| ChromaDB | ✅ | Persistent vector database with 10 docs |
| Embeddings | ✅ | SentenceTransformer all-MiniLM-L6-v2 |
| Retrieval | ✅ | Top-3 semantic similarity search |
| LLM Integration | ✅ | Anthropic Claude REST API |
| Security | ✅ | .env file with API key protection |
| Prompt Engineering | ✅ | Persona + Context + Task + Constraints |
| Error Handling | ✅ | 401, 404, 405, Timeout, Connection errors |
| RAG Readiness | ✅ | Retrieve → Augment → Generate pattern |

## 🧠 Knowledge Base Documents

The application loads 10 training documents:

| ID | Topic | Content | Relevance |
|----|-------|---------|-----------|
| emb_001 | Embeddings | Numerical vectors & semantic meaning | Core concept |
| emb_002 | Embeddings | Semantic search & keyword matching | Core concept |
| emb_003 | Vector DB | ChromaDB storage & retrieval | Core concept |
| llm_001 | LLMs | Architecture & transformer networks | Core concept |
| llm_002 | LLMs | Token processing & attention | Supporting |
| rag_001 | RAG | Retrieval-augmented generation flow | Core pattern |
| rag_002 | RAG | Reducing hallucinations with context | Core benefit |
| prompt_001 | Prompt Eng | Crafting effective prompts | Core skill |
| prompt_002 | Prompt Eng | Persona, context, task, constraints | Core skill |
| transformer_001 | Transformers | Self-attention & parallel processing | Supporting |

## 🔍 Vector Search Example

When user asks: "How does semantic search work?"

```python
query_embedding = embedding_model.encode("How does semantic search work?")
# Result: [0.234, -0.123, 0.567, ..., -0.345]  (384 dims)

results = collection.query(
    query_texts=["How does semantic search work?"],
    n_results=3
)

# ChromaDB returns top 3 by cosine similarity:
# 1. "Semantic search compares meaning rather than exact words..."
#    Distance: 0.1234 → Similarity: 0.8766 ✓ HIGHLY RELEVANT
#
# 2. "Embeddings are numerical vectors that capture meaning..."
#    Distance: 0.3456 → Similarity: 0.6544 ✓ RELEVANT
#
# 3. "Vector databases store embeddings and retrieve similar docs..."
#    Distance: 0.5678 → Similarity: 0.4322 ✓ SOMEWHAT RELEVANT
```

## 🛡️ Error Handling Flow

```
API Call to Claude
    ↓
├─ HTTP 200 → Parse response → Extract answer ✓
├─ HTTP 401 → "Invalid API key" error
├─ HTTP 404 → "Invalid endpoint/model" error
├─ HTTP 405 → "Invalid HTTP method" error
├─ Timeout → "Request timeout" error
└─ ConnectionError → "Cannot reach LLM API" error
    ↓
Return error message to frontend
    ↓
Display in error box with styling
```

## 📈 Performance Metrics

- **Embedding Generation**: ~50ms (SentenceTransformer)
- **ChromaDB Search**: ~10ms (in-memory similarity)
- **LLM API Call**: ~2-5 seconds (network dependent)
- **Total Request Time**: ~2.5-5.5 seconds
- **Vector Dimension**: 384 (all-MiniLM-L6-v2)
- **Database Size**: ~10 documents (easily scalable)
- **Similarity Metric**: Cosine (range: -1 to 1)

## 🔐 Security Considerations

✅ **Implemented:**
- API key loaded from .env (never hardcoded)
- No secrets in version control
- HTTPS-ready endpoints
- Input validation on questions
- Error messages don't leak sensitive info

⚠️ **Production Considerations:**
- Rate limiting (not implemented)
- Request logging (basic only)
- CORS headers (needed for cross-domain)
- API key rotation mechanism
- Request signing/verification

## 🚀 Scaling & Future Enhancements

**Current Limitations:**
- 10 documents (easily expandable to 1000s)
- Single collection (can add multiple)
- No authentication (suitable for demo)
- No persistent chat history

**Potential Enhancements:**
1. Add more training documents
2. Implement chat history storage
3. Add user authentication
4. Multi-language support
5. Document upload feature
6. Custom embedding models
7. Hybrid search (keyword + semantic)
8. Query expansion/reformulation
9. Response caching
10. Analytics dashboard

## 📝 Prompt Engineering Breakdown

```
Structure:
1. Persona: "You are a helpful GenAI training assistant for beginners"
2. Context: [Retrieved knowledge documents]
3. Task: "Provide a clear, beginner-friendly answer"
4. Constraints: "Use simple language, avoid jargon, 2-3 sentences max"

Reasoning:
- Persona: Guides response tone and style
- Context: Provides factual grounding (reduces hallucinations)
- Task: Clarifies what to do
- Constraints: Sets expectations and limits

Result: High-quality, beginner-appropriate responses
```

## 🎯 RAG Advantages Over Pure LLM

| Aspect | Pure LLM | RAG System |
|--------|----------|-----------|
| Hallucinations | High ⚠️ | Low ✅ |
| Factual Accuracy | Training data limited | Current knowledge ✅ |
| Explainability | "Black box" | Context visible ✅ |
| Up-to-date | Training cutoff | Real-time ✅ |
| Custom Domain | Retraining needed | Simple additions ✅ |
| Verifiability | Hard | Sources shown ✅ |

---

**This RAG implementation demonstrates production-quality patterns suitable for real applications.**
