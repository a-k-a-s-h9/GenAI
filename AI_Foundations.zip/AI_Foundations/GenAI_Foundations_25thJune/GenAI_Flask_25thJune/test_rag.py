#!/usr/bin/env python
"""
Test script for the GenAI Knowledge Assistant RAG pipeline.
Demonstrates the complete flow without requiring the Flask UI.
"""

import os
import json
import chromadb
import requests
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

# Load environment variables
load_dotenv()

API_KEY = os.getenv('ANTHROPIC_API_KEY')
LLM_ENDPOINT = os.getenv('LLM_ENDPOINT')
LLM_MODEL = os.getenv('LLM_MODEL')

# Initialize embedding model
print("Loading embedding model...")
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Initialize Chroma database
print("Connecting to ChromaDB...")
chroma_client = chromadb.PersistentClient(path="./chroma_db")
collection = chroma_client.get_or_create_collection(
    name="genai_knowledge",
    metadata={"hnsw:space": "cosine"}
)

print(f"✓ ChromaDB connected. Documents in database: {collection.count()}\n")

# Test queries
test_questions = [
    "What is the role of embeddings in GenAI?",
    "How does RAG improve LLM responses?",
    "What are transformers and why are they important?"
]

for i, question in enumerate(test_questions, 1):
    print(f"\n{'='*80}")
    print(f"Test {i}: {question}")
    print('='*80)

    # Step 1: Retrieve context
    print("\n1️⃣  Retrieving relevant context from ChromaDB...")
    results = collection.query(query_texts=[question], n_results=3)

    print(f"   Found {len(results['documents'][0])} relevant documents:\n")
    context_docs = []
    for j, doc in enumerate(results['documents'][0], 1):
        distance = results['distances'][0][j-1]
        similarity = 1 - distance
        topic = results['metadatas'][0][j-1].get('topic', 'Unknown')

        print(f"   [{j}] Topic: {topic}")
        print(f"       Similarity: {similarity:.4f}")
        print(f"       Distance: {distance:.4f}")
        print(f"       Text: {doc[:100]}...")
        print()

        context_docs.append({
            "text": doc,
            "topic": topic,
            "similarity": similarity
        })

    # Step 2: Call LLM
    print("2️⃣  Calling Claude LLM with retrieved context...")

    context_string = "\n".join([f"- {doc['text']}" for doc in context_docs])

    prompt = f"""You are a helpful GenAI training assistant for beginners. Your role is to explain complex concepts in simple, understandable language.

Context from knowledge base:
{context_string}

User Question: {question}

Please provide a clear, beginner-friendly answer based on the context above. Keep it concise (2-3 sentences max).
Constraints: Use simple language, avoid jargon, focus on practical understanding."""

    headers = {
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
    }

    payload = {
        "model": LLM_MODEL,
        "max_tokens": 500,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    try:
        response = requests.post(LLM_ENDPOINT, json=payload, headers=headers, timeout=30)

        if response.status_code == 200:
            data = response.json()
            if 'content' in data and len(data['content']) > 0:
                answer = data['content'][0]['text']
                print(f"\n3️⃣  Claude's Response:\n")
                print(f"   {answer}")
                print(f"\n✅ RAG pipeline completed successfully!")
            else:
                print(f"❌ Unexpected API response format")
        else:
            print(f"❌ API Error {response.status_code}")
            if response.status_code == 401:
                print("   Invalid or missing API key in .env file")
            elif response.status_code == 404:
                print("   Invalid endpoint or model name")
            print(f"   Response: {response.text[:200]}")

    except Exception as e:
        print(f"❌ Error: {str(e)}")

print(f"\n{'='*80}")
print("Test complete!")
print(f"{'='*80}\n")
