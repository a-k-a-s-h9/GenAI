# GenAI Knowledge Assistant - Flask RAG Application

A Retrieval-Augmented Generation (RAG) application built with Flask, ChromaDB, and Claude LLM. This assistant answers questions about GenAI concepts by retrieving relevant training context and generating beginner-friendly responses.

## 🎯 Project Overview

This application implements a complete RAG pipeline:
1. **User Question** → Converted to embedding using SentenceTransformer
2. **Vector Search** → Top 3 semantically similar documents retrieved from ChromaDB
3. **Context Assembly** → Retrieved documents combined with user question
4. **LLM Generation** → Claude generates a clear, beginner-friendly answer
5. **Response Display** → Shows question, context, similarity scores, and answer

## 📋 Features

✅ **Flask Web UI** - Simple, responsive interface for asking questions  
✅ **ChromaDB Integration** - Persistent vector database for semantic search  
✅ **SentenceTransformer** - all-MiniLM-L6-v2 model for embeddings  
✅ **Claude LLM Integration** - REST API calls to Anthropic's Claude  
✅ **Prompt Engineering** - Structured prompts with persona, context, task, constraints  
✅ **Error Handling** - 401, 404, 405, timeout and connection errors  
✅ **Security** - API keys loaded from .env, never hardcoded  
✅ **Knowledge Base** - Pre-loaded with 10 GenAI training documents  

## 🚀 Quick Start

### 1. Activate Virtual Environment
```bash
source .venv/bin/activate
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure Environment Variables
The `.env` file already contains:
```
ANTHROPIC_API_KEY=your_api_key_here
LLM_ENDPOINT=https://api.anthropic.com/v1/messages
LLM_MODEL=claude-3-5-sonnet-20241022
```

Update `ANTHROPIC_API_KEY` with your actual API key if needed.

### 4. Run the Application
```bash
python app.py
```

The application will:
- Initialize the embedding model (all-MiniLM-L6-v2)
- Create/load ChromaDB vector database
- Populate with 10 GenAI training documents
- Start Flask server on `http://localhost:5000`

### 5. Access the Web Interface
Open your browser and navigate to:
```
http://localhost:5000
```

## 📁 Project Structure

```
genai-flask-chroma-assistant/
├── app.py                    # Main Flask application
├── requirements.txt          # Python dependencies
├── .env                      # Environment variables (API keys)
├── README.md                 # This file
├── templates/
│   └── index.html           # Web UI template
├── static/
│   └── style.css            # Styling
└── chroma_db/               # Persistent ChromaDB (auto-created)
    └── chroma.parquet       # Vector embeddings and documents
```

## 🔧 Technical Details

### Embedding Model
- **Model**: SentenceTransformer (all-MiniLM-L6-v2)
- **Dimensions**: 384
- **Purpose**: Convert text queries and documents into semantic vectors

### Vector Database
- **Database**: ChromaDB with persistent storage
- **Collection**: `genai_knowledge`
- **Metric**: Cosine similarity
- **Documents**: 10 GenAI training samples

### LLM Integration
- **Provider**: Anthropic
- **Model**: Claude 3.5 Sonnet
- **Request Format**: REST API (JSON)
- **Response Handling**: Structured JSON parsing

### Prompt Structure
```
Persona: GenAI training assistant for beginners
Context: Retrieved relevant knowledge chunks
Task: Explain the concept clearly
Constraints: Use simple language, avoid jargon, 2-3 sentences max
```

## 📡 API Endpoints

### GET `/` 
Returns the web interface HTML page.

### GET `/health`
Health check endpoint. Returns:
```json
{
    "status": "ok",
    "knowledge_base_docs": 10
}
```

### POST `/ask`
Submit a question and get an RAG-based answer.

**Request:**
```json
{
    "question": "What is the role of embeddings in GenAI?"
}
```

**Response:**
```json
{
    "question": "What is the role of embeddings in GenAI?",
    "retrieved_context": [
        {
            "text": "Embeddings are numerical vectors...",
            "topic": "Embeddings",
            "distance": 0.1234
        },
        ...
    ],
    "answer": "Embeddings help GenAI systems...",
    "num_docs_retrieved": 3
}
```

**Error Responses:**
- **401**: Invalid or missing API key
- **404**: Endpoint or model not found
- **405**: Invalid HTTP method
- **500**: Server error (timeout, connection, etc.)

## 🗂️ Knowledge Base

The application includes pre-loaded training documents on:
- **Embeddings** (2 docs) - Vector representations, semantic search
- **LLMs** (2 docs) - Architecture, training, transformers
- **RAG** (2 docs) - Retrieval-augmented generation flow
- **Prompt Engineering** (2 docs) - Persona, context, task, constraints
- **Transformers** (1 doc) - Self-attention, parallel processing
- **Vector Databases** (1 doc) - Storage and retrieval of embeddings

Documents are indexed on startup and persist in `./chroma_db/`

## 🎓 Learning Outcomes

By implementing this application, you'll understand:
✓ How ChromaDB stores and retrieves embeddings  
✓ End-to-end RAG pipeline design  
✓ Semantic similarity search with embeddings  
✓ REST API calls to LLM providers  
✓ Error handling for API failures  
✓ Prompt engineering best practices  
✓ Flask application structure  
✓ Frontend-backend integration  

## 🔐 Security

- **No hardcoded secrets** - API keys loaded from .env only
- **Error handling** - API errors logged, sensitive info not exposed
- **Input validation** - Questions sanitized before processing
- **HTTPS ready** - Can be deployed behind HTTPS proxy

## 🐛 Troubleshooting

### Issue: "Invalid API key" error
**Solution**: Verify your ANTHROPIC_API_KEY in .env file

### Issue: "No relevant context found"
**Solution**: The question may not match any training documents. Try asking about: embeddings, LLMs, RAG, prompt engineering, transformers

### Issue: Connection timeout
**Solution**: Check internet connection and that Anthropic API is accessible

### Issue: ChromaDB not loading
**Solution**: Delete `./chroma_db/` folder and restart the app to reinitialize

## 📊 Example Interactions

**Question**: "What is the role of embeddings in GenAI?"

**Retrieved Context**:
- Embeddings are numerical vector representations...
- Semantic search compares meaning rather than keywords...
- Vector databases store embeddings and retrieve similar documents...

**Answer**:
"Embeddings help GenAI systems understand the meaning of text by converting words or sentences into numerical vectors. These vectors enable semantic search and help retrieve relevant context from databases like ChromaDB. This is crucial for RAG systems to find information before generating responses."

## 🚀 Deployment Considerations

For production:
1. Use a production WSGI server (Gunicorn, uWSGI)
2. Configure environment-specific .env files
3. Implement request rate limiting
4. Add logging and monitoring
5. Use reverse proxy (Nginx) for HTTPS
6. Containerize with Docker

## 📝 License

This is an educational project for GenAI training.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Verify API keys and endpoints
3. Check Flask debug mode logs
4. Review application code for error handling

---

**Status**: ✅ Ready for use  
**Last Updated**: 2026-06-25  
**Python Version**: 3.8+  
**Framework**: Flask 3.1+
