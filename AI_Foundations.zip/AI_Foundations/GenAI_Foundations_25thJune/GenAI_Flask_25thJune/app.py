import os
import json
import chromadb
import requests
import numpy as np
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Load configuration from .env
API_KEY = os.getenv('ANTHROPIC_API_KEY')
LLM_ENDPOINT = os.getenv('LLM_ENDPOINT')
LLM_MODEL = os.getenv('LLM_MODEL')

# Initialize embedding model
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Initialize Chroma database
chroma_client = chromadb.PersistentClient(path="./chroma_db")
collection = chroma_client.get_or_create_collection(
    name="genai_knowledge",
    metadata={"hnsw:space": "cosine"}
)

# Sample knowledge base for GenAI training
KNOWLEDGE_BASE = [
    {
        "id": "emb_001",
        "text": "Embeddings are numerical vector representations that capture semantic meaning of text. They convert words, phrases or documents into arrays of numbers that machine learning models can process.",
        "topic": "Embeddings"
    },
    {
        "id": "emb_002",
        "text": "Semantic search compares meaning rather than exact keyword matches using embeddings. It allows systems to find contextually relevant documents even if they use different words.",
        "topic": "Embeddings"
    },
    {
        "id": "emb_003",
        "text": "Vector databases like ChromaDB store embeddings and enable fast retrieval of semantically similar documents based on vector similarity calculations.",
        "topic": "Vector Databases"
    },
    {
        "id": "llm_001",
        "text": "Large Language Models (LLMs) are neural networks trained on vast amounts of text data to understand and generate human language. They use transformer architecture with attention mechanisms.",
        "topic": "LLMs"
    },
    {
        "id": "llm_002",
        "text": "LLMs process text through tokens and use context windows to understand relationships between words. The attention mechanism allows models to focus on relevant parts of input.",
        "topic": "LLMs"
    },
    {
        "id": "rag_001",
        "text": "Retrieval-Augmented Generation (RAG) combines information retrieval with text generation. It retrieves relevant context from a knowledge base before generating responses, improving accuracy and relevance.",
        "topic": "RAG"
    },
    {
        "id": "rag_002",
        "text": "RAG reduces hallucinations in LLMs by providing factual context. It grounds model responses in actual documents rather than relying solely on training data.",
        "topic": "RAG"
    },
    {
        "id": "prompt_001",
        "text": "Prompt engineering is the practice of crafting inputs to LLMs to get desired outputs. Effective prompts include clear instructions, examples, and constraints to guide model behavior.",
        "topic": "Prompt Engineering"
    },
    {
        "id": "prompt_002",
        "text": "A well-structured prompt includes: persona (who you are), context (background information), task (what to do), and constraints (what not to do or limitations).",
        "topic": "Prompt Engineering"
    },
    {
        "id": "transformer_001",
        "text": "Transformers are neural network architectures based on self-attention mechanisms. They process sequences in parallel unlike RNNs, making them efficient for large-scale language models.",
        "topic": "Transformers"
    }
]


def initialize_knowledge_base():
    """Populate Chroma with initial knowledge base."""
    if collection.count() == 0:
        texts = []
        ids = []
        metadatas = []

        for item in KNOWLEDGE_BASE:
            texts.append(item["text"])
            ids.append(item["id"])
            metadatas.append({"topic": item["topic"]})

        collection.add(
            documents=texts,
            ids=ids,
            metadatas=metadatas
        )
        print("✓ Knowledge base initialized with GenAI training content")


def retrieve_context(query, top_k=3):
    """Retrieve top-k semantically similar documents from ChromaDB."""
    results = collection.query(
        query_texts=[query],
        n_results=top_k
    )

    retrieved_docs = []
    if results['documents'] and len(results['documents']) > 0:
        for i, doc in enumerate(results['documents'][0]):
            distance = results['distances'][0][i] if results['distances'] else None
            metadata = results['metadatas'][0][i] if results['metadatas'] else {}
            retrieved_docs.append({
                "text": doc,
                "topic": metadata.get("topic", "General"),
                "distance": distance
            })

    return retrieved_docs


def call_llm(user_question, context_docs):
    """Call Claude API with retrieved context to generate answer."""
    # Prepare context string
    context_string = "\n".join([f"- {doc['text']}" for doc in context_docs])

    # Construct prompt with persona, context, task and constraints
    prompt = f"""You are a helpful GenAI training assistant for beginners. Your role is to explain complex concepts in simple, understandable language.

Context from knowledge base:
{context_string}

User Question: {user_question}

Please provide a clear, beginner-friendly answer based on the context above. Keep it concise (2-3 sentences max).
Constraints: Use simple language, avoid jargon, focus on practical understanding."""

    headers = {
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
    }

    payload = {
        "model": LLM_MODEL,
        "max_tokens": 500,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    try:
        response = requests.post(LLM_ENDPOINT, json=payload, headers=headers, timeout=30)

        if response.status_code == 401:
            return {"error": "401 Unauthorized - Invalid API key. Check ANTHROPIC_API_KEY in .env"}
        elif response.status_code == 404:
            return {"error": "404 Not Found - Invalid endpoint or model. Check LLM_ENDPOINT and LLM_MODEL in .env"}
        elif response.status_code == 405:
            return {"error": "405 Method Not Allowed - Invalid HTTP method"}
        elif response.status_code != 200:
            return {"error": f"API Error {response.status_code}: {response.text}"}

        data = response.json()

        # Extract response text from Claude API format
        if 'choices' in data and len(data['choices']) > 0:
            answer = data['choices'][0]['message']['content']
            return {"answer": answer}
        else:
            return {"error": "Unexpected API response format"}

    except requests.exceptions.Timeout:
        return {"error": "Request timeout - LLM API did not respond in time"}
    except requests.exceptions.ConnectionError:
        return {"error": "Connection error - Could not reach LLM API"}
    except Exception as e:
        return {"error": f"Error calling LLM: {str(e)}"}


@app.route('/')
def index():
    """Render main page."""
    return render_template('index.html')


@app.route('/ask', methods=['POST'])
def ask_question():
    """Handle user question and return RAG response."""
    try:
        data = request.json
        user_question = data.get('question', '').strip()

        if not user_question:
            return jsonify({"error": "Please enter a question"}), 400

        # Step 1: Retrieve relevant context
        context_docs = retrieve_context(user_question, top_k=3)

        if not context_docs:
            return jsonify({"error": "No relevant context found in knowledge base"}), 404

        # Step 2: Call LLM with retrieved context
        llm_response = call_llm(user_question, context_docs)

        if "error" in llm_response:
            return jsonify(llm_response), 500

        # Prepare response data
        response_data = {
            "question": user_question,
            "retrieved_context": context_docs,
            "answer": llm_response.get("answer", ""),
            "num_docs_retrieved": len(context_docs)
        }

        return jsonify(response_data), 200

    except Exception as e:
        return jsonify({"error": f"Server error: {str(e)}"}), 500


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({"status": "ok", "knowledge_base_docs": collection.count()}), 200


if __name__ == '__main__':
    initialize_knowledge_base()
    app.run(debug=True, host='0.0.0.0', port=5006)
